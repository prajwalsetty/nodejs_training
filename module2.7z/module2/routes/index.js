module.exports = {
  posts: require('./posts.js'),
  comments: require('./comments.js')
}
const csvFilePath = 'customer-data.csv'
const fs = require('fs')
const csv = require('csvtojson')

let jsonArray = []

var c = csv();
c.fromFile(csvFilePath)
.on('json',function(jsonObj){
    jsonArray.push(jsonObj)
})
.on('done',function(error){
fs.writeFile('jsonOutputFile.json', JSON.stringify(jsonArray,null,2), function(error){
process.exit(0)
})
})
